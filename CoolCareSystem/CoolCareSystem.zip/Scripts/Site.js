﻿$(document).ready(function () {

    $("input").attr('maxlength', '50');   

});