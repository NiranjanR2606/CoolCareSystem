﻿$(document).ready(function () {

    setTimeout(function () {
        $(".alert-message").fadeOut("fast");
    }, 2000);

    var show = 1;

    $("i.showpassword").parent().click(function () {
        if (show % 2 != 0) {
            $("i.showpassword").removeClass("glyphicon-eye-open");
            $("i.showpassword").addClass("glyphicon-eye-close");
            $("i.showpassword").parent().parent().find("input").attr("type", "text");
            show++;
        }
        else if (show % 2 == 0) {
            $("i.showpassword").removeClass("glyphicon-eye-close");
            $("i.showpassword").addClass("glyphicon-eye-open");
            $("i.showpassword").parent().parent().find("input").attr("type", "password");
            show++;
        }
    });
});